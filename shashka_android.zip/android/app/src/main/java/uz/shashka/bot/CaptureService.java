package uz.shashka.bot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;
import android.view.WindowManager;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

/** Ekran tasvirini oladi (MediaProjection) va botni ishga tushiradi. */
public class CaptureService extends Service {
    static final String ACTION_STOP = "uz.shashka.bot.STOP";
    static final String CHANNEL = "shashka";
    static volatile boolean running = false;

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private ChessBot bot;
    private HandlerThread ht;
    private Handler handler;
    private PowerManager.WakeLock wl;
    private volatile Frame lastFrame;
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(1, buildNotification(BotLog.status));
            handler.postDelayed(this, 2000);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification(String text) {
        Intent stop = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(this, 1, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Shashka bot")
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_delete), "To'xtatish", pi).build());
        return b.build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Shashka bot", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification(running ? BotLog.status : "Ishga tushmoqda...");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
        if (running || intent == null) return START_NOT_STICKY;
        try {
            startCapture(intent);
        } catch (Throwable e) {
            BotLog.say("Ekran yozishni boshlab bo'lmadi: " + e);
            shutdown();
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private void startCapture(Intent intent) {
        File lf = new File(getFilesDir(), "shashka_log.txt");
        BotLog.setFile(lf);

        String exe = getApplicationInfo().nativeLibraryDir + "/libstockfish.so";
        UciClient eng = new UciClient(exe);
        BotLog.log("Stockfish: " + exe + " mavjud=" + new File(exe).exists());

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) {
            BotLog.say("Ekran yozishga ruxsat olinmadi.");
            shutdown();
            stopSelf();
            return;
        }
        ht = new HandlerThread("shashka-capture");
        ht.start();
        handler = new Handler(ht.getLooper());
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                BotLog.log("MediaProjection to'xtatildi");
                shutdown();
                stopSelf();
            }
        }, handler);

        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Rect bounds = wm.getMaximumWindowMetrics().getBounds();
        int w = bounds.width(), h = bounds.height();
        int dpi = getResources().getDisplayMetrics().densityDpi;
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        vd = projection.createVirtualDisplay("shashka", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        BotLog.log("ekran yozish boshlandi " + w + "x" + h + " dpi=" + dpi);

        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "shashka:bot");
            wl.acquire(3 * 60 * 60 * 1000L);
        } catch (Throwable e) {
            BotLog.log("wakelock: " + e);
        }

        running = true;
        Screen screen = new Screen() {
            @Override
            public Frame grab() {
                return CaptureService.this.grabFrame();
            }
        };
        bot = new ChessBot(screen, new TapService.Impl(), eng);
        bot.start();
        handler.postDelayed(ticker, 2000);
    }

    private Frame grabFrame() {
        ImageReader r = reader;
        if (r == null) return lastFrame;
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img != null) {
                Image.Plane pl = img.getPlanes()[0];
                ByteBuffer bb = pl.getBuffer();
                int rs = pl.getRowStride();
                int w = img.getWidth(), h = img.getHeight();
                int[] px = new int[w * h];
                IntBuffer ib = bb.order(ByteOrder.nativeOrder()).asIntBuffer();
                int rowInts = rs / 4;
                for (int y = 0; y < h; y++) {
                    ib.position(y * rowInts);
                    ib.get(px, y * w, w);
                }
                for (int i = 0; i < px.length; i++) {
                    int q = px[i];
                    px[i] = ((q & 255) << 16) | (q & 0xFF00) | ((q >> 16) & 255);
                }
                lastFrame = new Frame(w, h, px);
            }
        } catch (Throwable e) {
            BotLog.log("tasvir olishda xato: " + e);
        } finally {
            if (img != null) img.close();
        }
        return lastFrame;
    }

    private synchronized void shutdown() {
        running = false;
        try {
            if (bot != null) bot.requestStop();
        } catch (Throwable ignored) {
        }
        bot = null;
        try {
            if (vd != null) vd.release();
        } catch (Throwable ignored) {
        }
        vd = null;
        try {
            if (reader != null) reader.close();
        } catch (Throwable ignored) {
        }
        reader = null;
        try {
            if (projection != null) projection.stop();
        } catch (Throwable ignored) {
        }
        projection = null;
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
        }
        wl = null;
        try {
            if (ht != null) ht.quitSafely();
        } catch (Throwable ignored) {
        }
        ht = null;
        try {
            stopForeground(true);
        } catch (Throwable ignored) {
        }
        BotLog.status = "To'xtatilgan";
    }

    @Override
    public void onDestroy() {
        shutdown();
        super.onDestroy();
    }
}
