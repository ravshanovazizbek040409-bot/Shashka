package uz.shashka.bot;

/** Shaxmat holati: FEN yasash, rokirovka/en-passant kuzatuvi, UCI yurishlarini taxtaga qo'llash. */
final class ChessGame {
    /** Rokirovka huquqlari: K, Q (oq), k, q (qora). */
    boolean[] castle = {true, true, true, true};

    /** Ekrandagi tasvirni FEN tartibiga o'giradi: [0] = 8-gorizontal, [r][0] = a-vertikal. */
    static char[][] toFen(char[][] img, char mine) {
        char[][] b = new char[8][8];
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) b[r][c] = mine == 'b' ? img[7 - r][7 - c] : img[r][c];
        return b;
    }

    /** FEN tartibidagi katak (r,c) ekrandagi qaysi katakka to'g'ri keladi. */
    static int[] imgCell(int r, int c, char mine) {
        return mine == 'b' ? new int[]{7 - r, 7 - c} : new int[]{r, c};
    }

    static boolean valid(char[][] b) {
        int wk = 0, bk = 0, wp = 0, bp = 0, wn = 0, bn = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                char ch = b[r][c];
                if (ch == '?') return false;
                if (ch == 'K') wk++;
                if (ch == 'k') bk++;
                if (ch == 'P') wp++;
                if (ch == 'p') bp++;
                if (ch != '.') {
                    if (Character.isUpperCase(ch)) wn++; else bn++;
                }
                if ((ch == 'P' || ch == 'p') && (r == 0 || r == 7)) return false;
            }
        }
        return wk == 1 && bk == 1 && wp <= 8 && bp <= 8 && wn <= 16 && bn <= 16;
    }

    static boolean isInitial(char[][] b) {
        String[] init = {"rnbqkbnr", "pppppppp", "........", "........", "........", "........", "PPPPPPPP", "RNBQKBNR"};
        for (int r = 0; r < 8; r++) if (!new String(b[r]).equals(init[r])) return false;
        return true;
    }

    static String sig(char[][] b) {
        StringBuilder sb = new StringBuilder(64);
        for (char[] row : b) sb.append(row);
        return sb.toString();
    }

    void resetCastle() {
        castle = new boolean[]{true, true, true, true};
    }

    /** Taxtadan ko'rinib turgan rokirovka huquqlarini kamaytiradi (bir marta yo'qolgan qaytmaydi). */
    void updateCastle(char[][] b) {
        if (b[7][4] != 'K') { castle[0] = false; castle[1] = false; }
        if (b[7][7] != 'R') castle[0] = false;
        if (b[7][0] != 'R') castle[1] = false;
        if (b[0][4] != 'k') { castle[2] = false; castle[3] = false; }
        if (b[0][7] != 'r') castle[2] = false;
        if (b[0][0] != 'r') castle[3] = false;
    }

    /** Raqib piyodasi ikki katak yurgan bo'lsa en-passant katagi ("e6"), aks holda "-". */
    static String epSquare(char[][] prev, char[][] cur, char mine) {
        if (prev == null) return "-";
        for (int f = 0; f < 8; f++) {
            if (mine == 'w') {   // raqib qora
                if (prev[1][f] == 'p' && cur[1][f] == '.' && cur[3][f] == 'p' && prev[3][f] == '.' && prev[2][f] == '.' && cur[2][f] == '.')
                    return "" + (char) ('a' + f) + "6";
            } else {
                if (prev[6][f] == 'P' && cur[6][f] == '.' && cur[4][f] == 'P' && prev[4][f] == '.' && prev[5][f] == '.' && cur[5][f] == '.')
                    return "" + (char) ('a' + f) + "3";
            }
        }
        return "-";
    }

    String fen(char[][] b, char mine, String ep) {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < 8; r++) {
            int empty = 0;
            for (int c = 0; c < 8; c++) {
                char ch = b[r][c];
                if (ch == '.') {
                    empty++;
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0; }
                    sb.append(ch);
                }
            }
            if (empty > 0) sb.append(empty);
            if (r < 7) sb.append('/');
        }
        sb.append(' ').append(mine == 'w' ? 'w' : 'b').append(' ');
        String cs = (castle[0] ? "K" : "") + (castle[1] ? "Q" : "") + (castle[2] ? "k" : "") + (castle[3] ? "q" : "");
        sb.append(cs.isEmpty() ? "-" : cs).append(' ').append(ep == null ? "-" : ep).append(" 0 1");
        return sb.toString();
    }

    static int file(char c) { return c - 'a'; }
    static int rankRow(char c) { return 8 - (c - '0'); }

    /** UCI yurishini ("e2e4", "e7e8q", "e1g1") FEN-taxtaga qo'llaydi (yangi nusxa). */
    static char[][] apply(char[][] b, String mv) {
        char[][] n = new char[8][];
        for (int i = 0; i < 8; i++) n[i] = b[i].clone();
        int fc = file(mv.charAt(0)), fr = rankRow(mv.charAt(1)), tc = file(mv.charAt(2)), tr = rankRow(mv.charAt(3));
        char p = n[fr][fc];
        char target = n[tr][tc];
        n[fr][fc] = '.';
        if ((p == 'K' || p == 'k') && Math.abs(tc - fc) == 2) {
            int rr = fr;
            if (tc > fc) { n[rr][5] = n[rr][7]; n[rr][7] = '.'; } else { n[rr][3] = n[rr][0]; n[rr][0] = '.'; }
        }
        if ((p == 'P' || p == 'p') && fc != tc && target == '.') n[fr][tc] = '.';   // en passant
        if (mv.length() >= 5) {
            char q = mv.charAt(4);
            p = Character.isUpperCase(p) ? Character.toUpperCase(q) : Character.toLowerCase(q);
        }
        n[tr][tc] = p;
        return n;
    }

    /** Taxta tasviridan rangni taxmin qilish: pastki yarmida ko'p dona qaysi rangda bo'lsa, shu bizniki. */
    static char guessMine(char[][] img) {
        int w = 0, b = 0;
        for (int r = 4; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                char ch = img[r][c];
                if (ch == '.' || ch == '?') continue;
                if (Character.isUpperCase(ch)) w++; else b++;
            }
        return w >= b ? 'w' : 'b';
    }
}
