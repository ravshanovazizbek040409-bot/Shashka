package uz.shashka.bot;

import java.util.Base64;

/** Gramora shaxmat taxtasini ekran tasvirida topish va donalarni o'qish. */
final class ChessVision {
    private ChessVision() {}

    static final int N = 48;

    /** Taxta chegarasi {x0, y0, s} (s = katak o'lchami) yoki null. */
    static double[] detectBoard(Frame f) {
        final int W = f.w, H = f.h;
        int[] rows = new int[H], cols = new int[W];
        for (int y = 0; y < H; y++) {
            int base = y * W;
            for (int x = 0; x < W; x++) {
                int p = f.rgb[base + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                if (r > 225 && g > 195 && g < 235 && b > 140 && b < 195 && r - b > 45 && r - b < 95) {
                    rows[y]++;
                    cols[x]++;
                }
            }
        }
        int[] ys = span(rows, 120, 140), xs = span(cols, 120, 140);
        if (ys == null || xs == null) return null;
        double x0 = xs[0] - 4, x1 = xs[1] + 4, y0 = ys[0] - 4, y1 = ys[1] + 4;
        double w = x1 - x0, h = y1 - y0;
        if (w < f.w * 0.4 || Math.abs(w - h) > 0.06 * w) return null;
        return new double[]{x0, y0, (w + h) / 16.0};
    }

    private static int[] span(int[] v, int thr, int gap) {
        int[] best = null, cur = null;
        int bl = -1;
        for (int i = 0; i < v.length; i++) {
            if (v[i] <= thr) continue;
            if (cur != null && i - cur[1] <= gap) {
                cur[1] = i;
            } else {
                if (cur != null && cur[1] - cur[0] > bl) {
                    bl = cur[1] - cur[0];
                    best = cur;
                }
                cur = new int[]{i, i};
            }
        }
        if (cur != null && cur[1] - cur[0] > bl) best = cur;
        return best;
    }

    /** Katakning N x N o'lchamli niqobi (true = fon emas) va o'rtacha yorqinligi. */
    static final class Cell {
        boolean[] fg = new boolean[N * N];
        double area;
        double med;
    }

    static Cell cell(Frame f, double[] box, int r, int c) {
        double s = box[2];
        double xa = box[0] + c * s, ya = box[1] + r * s;
        double m = s * 0.12;
        double cx0 = xa + m, cy0 = ya + m, cw = s - 2 * m;
        Cell out = new Cell();
        float[] br = new float[N * N];
        for (int j = 0; j < N; j++) {
            for (int i = 0; i < N; i++) {
                int sx0 = (int) Math.floor(cx0 + cw * i / N), sx1 = (int) Math.floor(cx0 + cw * (i + 1) / N);
                int sy0 = (int) Math.floor(cy0 + cw * j / N), sy1 = (int) Math.floor(cy0 + cw * (j + 1) / N);
                if (sx1 <= sx0) sx1 = sx0 + 1;
                if (sy1 <= sy0) sy1 = sy0 + 1;
                long sr = 0, sg = 0, sb = 0;
                int n = 0;
                for (int y = sy0; y < sy1; y++) {
                    if (y < 0 || y >= f.h) continue;
                    for (int x = sx0; x < sx1; x++) {
                        if (x < 0 || x >= f.w) continue;
                        int p = f.rgb[y * f.w + x];
                        sr += (p >> 16) & 255;
                        sg += (p >> 8) & 255;
                        sb += p & 255;
                        n++;
                    }
                }
                if (n == 0) continue;
                int R = (int) (sr / n), G = (int) (sg / n), B = (int) (sb / n);
                int rb = R - B;
                boolean lightbg = R > 215 && rb > 50 && rb < 100 && G > 180;
                boolean darkbg = R > 40 && R < 125 && rb > 30 && rb < 95 && G < 80;
                boolean yel = R > 180 && G > 130 && rb > 85;
                out.fg[j * N + i] = !(lightbg || darkbg || yel);
                br[j * N + i] = (R + G + B) / 3f;
            }
        }
        // burchak yozuvlari (qator raqami / harf) ni tashlash
        for (int j = 0; j < N; j++) {
            for (int i = 0; i < N; i++) {
                if (j < (int) (N * 0.22) && i < (int) (N * 0.2)) out.fg[j * N + i] = false;
                if (j >= (int) (N * 0.8) && i >= (int) (N * 0.78)) out.fg[j * N + i] = false;
            }
        }
        int cnt = 0;
        for (boolean b : out.fg) if (b) cnt++;
        out.area = cnt / (double) (N * N);
        if (cnt > 0) {
            float[] vals = new float[cnt];
            int k = 0;
            for (int i = 0; i < N * N; i++) if (out.fg[i]) vals[k++] = br[i];
            java.util.Arrays.sort(vals);
            out.med = (cnt % 2 == 1) ? vals[cnt / 2] : (vals[cnt / 2 - 1] + vals[cnt / 2]) / 2.0;
        }
        return out;
    }

    static double iou(boolean[] m, boolean[] t, int maxs) {
        double best = 0;
        for (int dy = -maxs; dy <= maxs; dy++) {
            for (int dx = -maxs; dx <= maxs; dx++) {
                int inter = 0, uni = 0;
                for (int y = 0; y < N; y++) {
                    int ty = (y - dy + N) % N;
                    for (int x = 0; x < N; x++) {
                        int tx = (x - dx + N) % N;
                        boolean a = m[y * N + x], b = t[ty * N + tx];
                        if (a && b) inter++;
                        if (a || b) uni++;
                    }
                }
                if (uni > 0) best = Math.max(best, inter / (double) uni);
            }
        }
        return best;
    }

    static boolean[] unpack(String b64) {
        byte[] d = Base64.getDecoder().decode(b64);
        boolean[] m = new boolean[N * N];
        for (int i = 0; i < N * N; i++) m[i] = (d[i >> 3] & (1 << (i & 7))) != 0;
        return m;
    }

    static String pack(boolean[] m) {
        byte[] d = new byte[N * N / 8];
        for (int i = 0; i < N * N; i++) if (m[i]) d[i >> 3] |= (byte) (1 << (i & 7));
        return Base64.getEncoder().encodeToString(d);
    }

    private static boolean[][] tmplMasks = null;
    private static char[] tmplChar = null;   // 'P','p',...

    private static synchronized void loadTemplates() {
        if (tmplMasks != null) return;
        String[][] t = ChessTemplates.T;
        tmplMasks = new boolean[t.length][];
        tmplChar = new char[t.length];
        for (int i = 0; i < t.length; i++) {
            char ty = t[i][0].charAt(0);
            tmplChar[i] = t[i][1].equals("w") ? Character.toUpperCase(ty) : ty;
            tmplMasks[i] = unpack(t[i][2]);
        }
    }

    /** '.' bo'sh; aks holda dona harfi (katta = oq). conf[0] ga ishonch yoziladi. */
    static char classify(Cell c, double[] conf) {
        loadTemplates();
        conf[0] = 1.0;
        if (c.area < 0.14) return '.';
        boolean white = c.med > 130;
        char best = '?';
        double bv = 0;
        for (int i = 0; i < tmplMasks.length; i++) {
            boolean tw = Character.isUpperCase(tmplChar[i]);
            if (tw != white) continue;
            double v = iou(c.fg, tmplMasks[i], 2);
            if (v > bv) {
                bv = v;
                best = tmplChar[i];
            }
        }
        conf[0] = bv;
        if (bv < 0.45) return '?';
        return best;
    }

    /** Ekrandagi 8x8 tasvir (yuqori chap = ekran chap-yuqori). null: o'qib bo'lmadi. */
    static char[][] read(Frame f, double[] box, double[] minConf) {
        char[][] b = new char[8][8];
        double mc = 1.0;
        double[] cf = new double[1];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                b[r][c] = classify(cell(f, box, r, c), cf);
                if (cf[0] < mc) mc = cf[0];
            }
        }
        if (minConf != null) minConf[0] = mc;
        return b;
    }

    /** Navbat sizdami (pastdagi yashil "SIZNING NAVBATINGIZ" yozuvi). */
    static boolean myTurn(Frame f, double[] box) {
        double s = box[2];
        int ya = (int) (box[1] + 8 * s + 1.1 * s), yb = (int) (box[1] + 8 * s + 2.0 * s);
        int xa = (int) (box[0] + 2.0 * s), xb = (int) (box[0] + 6.0 * s);
        int green = 0;
        for (int y = Math.max(0, ya); y < Math.min(f.h, yb); y++) {
            for (int x = Math.max(0, xa); x < Math.min(f.w, xb); x++) {
                int p = f.rgb[y * f.w + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                if (g > r + 40 && g > b + 40) green++;
            }
        }
        return green >= 800.0 * (s * s) / (106.0 * 106.0);
    }

    /** O'zingizning rangingiz: pastdagi avatar belgisidagi oq dona ('w') bo'lsa 'w', aks holda 0 (noma'lum). */
    static char myColor(Frame f, double[] box) {
        double s = box[2];
        int cx = (int) (box[0] + 0.55 * s), cy = (int) (box[1] + 8 * s + 3.53 * s);
        int x0 = cx - (int) (0.14 * s), x1 = cx + (int) (0.24 * s), y0 = cy - (int) (0.28 * s), y1 = cy + (int) (0.05 * s);
        int bright = 0, n = 0;
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                if (x < 0 || y < 0 || x >= f.w || y >= f.h) continue;
                int p = f.rgb[y * f.w + x];
                int v = (((p >> 16) & 255) + ((p >> 8) & 255) + (p & 255)) / 3;
                if (v > 200) bright++;
                n++;
            }
        }
        if (n == 0) return 0;
        return bright / (double) n > 0.12 ? 'w' : 0;
    }
}
