package uz.shashka.bot;

/** Ekran tasviri: har bir piksel 0xRRGGBB. */
final class Frame {
    final int w, h;
    final int[] rgb;

    Frame(int w, int h, int[] rgb) {
        this.w = w;
        this.h = h;
        this.rgb = rgb;
    }
}
