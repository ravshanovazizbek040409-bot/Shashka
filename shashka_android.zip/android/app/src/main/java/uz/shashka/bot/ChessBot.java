package uz.shashka.bot;

import java.util.Random;

/** Shaxmat sikli: taxtani o'qiydi, navbat sizda bo'lsa Stockfish'dan yurish olib, ekranga bosadi. */
final class ChessBot extends Thread {
    static volatile double thinkScale = 2.0;   // MainActivity tanlaydi
    private static final String[] MODES = {"click", "slow", "drag", "slow", "click"};

    private final Screen screen;
    private final Tapper tapper;
    private final UciClient eng;
    private final Random rnd = new Random();
    private final ChessGame game = new ChessGame();
    private volatile boolean stopFlag = false;

    ChessBot(Screen screen, Tapper tapper, UciClient eng) {
        super("shaxmat-bot");
        setDaemon(true);
        this.screen = screen;
        this.tapper = tapper;
        this.eng = eng;
    }

    void requestStop() {
        stopFlag = true;
        interrupt();
    }

    private boolean nap(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            return false;
        }
        return !stopFlag;
    }

    @Override
    public void run() {
        try {
            loop();
        } catch (Throwable e) {
            BotLog.say("Xato: " + e);
            java.io.StringWriter sw = new java.io.StringWriter();
            e.printStackTrace(new java.io.PrintWriter(sw));
            BotLog.log(sw.toString());
        }
        eng.close();
        BotLog.say("To'xtatildi");
    }

    private float[] center(double[] box, int[] cell) {
        double s = box[2];
        double jx = (rnd.nextDouble() - 0.5) * s * 0.25, jy = (rnd.nextDouble() - 0.5) * s * 0.25;
        return new float[]{(float) (box[0] + (cell[1] + 0.5) * s + jx), (float) (box[1] + (cell[0] + 0.5) * s + jy)};
    }

    private static int[] sqCell(String sq, char mine) {
        return ChessGame.imgCell(ChessGame.rankRow(sq.charAt(1)), ChessGame.file(sq.charAt(0)), mine);
    }

    private void play(double[] box, String mv, char mine, String mode, double mult) {
        float[] a = center(box, sqCell(mv.substring(0, 2), mine));
        float[] b = center(box, sqCell(mv.substring(2, 4), mine));
        if (mode.equals("drag")) {
            tapper.swipe(a[0], a[1], b[0], b[1], 350);
            nap((long) (600 * mult));
            return;
        }
        boolean slow = mode.equals("slow");
        tapper.tap(a[0], a[1], slow ? 140 : 60);
        nap((long) ((slow ? 700 : 500) * mult));
        if (stopFlag) return;
        tapper.tap(b[0], b[1], slow ? 140 : 60);
        nap((long) ((slow ? 600 : 350) * mult));
    }

    private void loop() {
        double[] box = null;
        char mine = 0;
        char[][] prevStable = null;   // raqib yurishidan oldingi (bizning yurishimizdan keyingi) taxta
        char[][] lastBefore = null, lastAfter = null;
        long tSent = 0;
        int fails = 0, unstable = 0, badReads = 0, noFrame = 0;
        String lastWait = "";

        BotLog.say("Ishga tushdi. Gramora shaxmat ochiq bo'lsin.");
        if (!eng.start()) {
            BotLog.say("Stockfish ishga tushmadi (libstockfish.so). Logni yuboring.");
            return;
        }
        while (!stopFlag) {
            Frame f1 = screen.grab();
            if (f1 == null) {
                if (++noFrame == 20) BotLog.say("Ekran tasviri kelmayapti");
                if (!nap(200)) break;
                continue;
            }
            noFrame = 0;
            if (box == null) {
                box = ChessVision.detectBoard(f1);
                if (box == null) {
                    BotLog.say("Taxta topilmadi. Telegram'da Gramora shaxmat o'yini ochiq turibdimi?");
                    if (!nap(800)) break;
                    continue;
                }
                BotLog.log(String.format("taxta topildi: x=%.0f y=%.0f katak=%.1f ekran %dx%d", box[0], box[1], box[2], f1.w, f1.h));
            }
            double[] mc1 = new double[1], mc2 = new double[1];
            char[][] img1 = ChessVision.read(f1, box, mc1);
            boolean t1 = ChessVision.myTurn(f1, box);
            if (!nap(120)) break;
            Frame f2 = screen.grab();
            if (f2 == null) f2 = f1;
            char[][] img2 = ChessVision.read(f2, box, mc2);
            boolean t2 = ChessVision.myTurn(f2, box);
            if (!ChessGame.sig(img1).equals(ChessGame.sig(img2))) {
                if (++unstable == 4) BotLog.say("Taxta harakatda (animatsiya). Kutyapman...");
                continue;
            }
            unstable = 0;
            boolean turn = t1 && t2;

            char col = ChessVision.myColor(f2, box);
            if (col == 0) col = (mine != 0 && lastAfter != null) ? mine : ChessGame.guessMine(img2);
            char[][] fenB = ChessGame.toFen(img2, col);
            if (!ChessGame.valid(fenB)) {
                BotLog.say("Taxta o'qilmadi. Qayta qidiryapman...");
                BotLog.log("o'qilgan: " + ChessGame.sig(img2) + " ishonch=" + String.format("%.2f", mc2[0]));
                if (++badReads >= 3) {
                    box = null;
                    badReads = 0;
                }
                if (!nap(700)) break;
                continue;
            }
            badReads = 0;

            if (ChessGame.isInitial(fenB) && (mine == 0 || lastAfter != null || mine != col)) {
                mine = col;
                game.resetCastle();
                prevStable = null;
                lastBefore = lastAfter = null;
                fails = 0;
                eng.newGame();
                BotLog.say("Yangi o'yin. Siz: " + (mine == 'w' ? "OQ" : "QORA") + ".");
            }
            if (mine == 0) {
                mine = col;
                BotLog.say("O'yin o'rtasidan qo'shildim. Siz: " + (mine == 'w' ? "OQ" : "QORA") + ".");
            }
            game.updateCastle(fenB);

            if (!turn) {
                if (!"w".equals(lastWait)) BotLog.say("Raqib o'ylayapti. Kutyapman...");
                lastWait = "w";
                prevStable = fenB;
                if (!nap(150)) break;
                continue;
            }
            lastWait = "";

            String cur = ChessGame.sig(fenB);
            if (lastAfter != null) {
                if (cur.equals(ChessGame.sig(lastAfter))) {   // yurishimiz ko'rindi, lekin navbat belgisi hali yangilanmagan
                    if (!nap(300)) break;
                    continue;
                }
                if (lastBefore != null && cur.equals(ChessGame.sig(lastBefore))) {   // yurish qabul qilinmadi
                    if (System.currentTimeMillis() - tSent < 1500) {
                        if (!nap(250)) break;
                        continue;
                    }
                    fails++;
                    BotLog.say("Yurish qabul qilinmadi (" + fails + "). Boshqacha usul bilan urinaman.");
                    if (fails >= 8) {
                        BotLog.say("Yurish bajarilmayapti. Pauza.");
                        if (!nap(5000)) break;
                        fails = 0;
                    }
                } else {
                    fails = 0;
                }
            }

            if (!tapper.available()) {
                BotLog.say("Accessibility xizmati yoqilmagan! Sozlamalarda yoqing.");
                if (!nap(1500)) break;
                continue;
            }

            String ep = ChessGame.epSquare(prevStable, fenB, mine);
            String fen = game.fen(fenB, mine, ep);
            BotLog.log("FEN: " + fen);
            long think = (long) (1500 * thinkScale);
            String mv = eng.best(fen, think);
            if (mv == null || mv.length() < 4) {
                BotLog.say("Dvigatel yurish bermadi (o'yin tugagan?).");
                if (!nap(1500)) break;
                continue;
            }
            String mode = MODES[Math.min(fails, 4)];
            BotLog.say("Yuryapman: " + mv + " (" + mode + ")");
            BotLog.log("yuraman: " + mv + " usul=" + mode);
            play(box, mv, mine, mode, 1.0 + 0.6 * fails);
            if (mv.length() >= 5) BotLog.log("Piyoda ayirboshlash: " + mv.charAt(4) + " (dialog bo'lsa, hozircha qo'lda tanlang)");
            lastBefore = fenB;
            lastAfter = ChessGame.apply(fenB, mv);
            tSent = System.currentTimeMillis();
            if (!nap(900)) break;
        }
    }
}
